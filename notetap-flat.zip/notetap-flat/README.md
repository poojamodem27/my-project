# NoteTap 3D (flat folder)

Anni files okate folder lo unnayi (subfolders ledu).

    npm install
    npm run dev

Browser lo http://localhost:5173
